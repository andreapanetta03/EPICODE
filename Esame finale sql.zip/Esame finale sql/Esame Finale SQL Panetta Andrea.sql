create schema ToysGroup;

create table Prodotti 
	(
	id_prodotto integer not null,
	nome_prodotto varchar(50),
	categoria_prodotto varchar(50),
	prezzo_prodotto double
	);
    
create table Vendite 
	(
	id_vendita int not null,
	id_regione integer,
	id_prodotto integer,
	prezzo_prodotto double,
	quantità_prodotto integer,
    data_vendita date,
	totale double
	);
    
create table Regioni
	(
	id_regione integer not null,
	nome_regione varchar (50)
	);
    
insert into Regioni (id_regione,nome_regione) values (1,"Stati Uniti");
insert into Regioni (id_regione,nome_regione) values (2,"Francia");
insert into Regioni (id_regione,nome_regione) values (3,"Grecia");
insert into Regioni (id_regione,nome_regione) values (4, "Macedonia");
insert into Regioni (id_regione,nome_regione) values (5,"Italia");

select * from Regioni;


-- inserimento prodotti in tabella
insert into prodotti(id_prodotto,nome_prodotto,categoria_prodotto,prezzo_prodotto) values (1,"BARBIE","Bambole",20.00);
insert into prodotti(id_prodotto,nome_prodotto,categoria_prodotto,prezzo_prodotto) values (2,"BARBAPAPA'","Peluche",15.00);
insert into prodotti(id_prodotto,nome_prodotto,categoria_prodotto,prezzo_prodotto) values (3,"CICCIOBELLO","Bambole",30.00);
insert into prodotti(id_prodotto,nome_prodotto,categoria_prodotto,prezzo_prodotto) values (4,"MARIO LAVA E STIRA","Giochi D'imitazione",90.00);
insert into prodotti(id_prodotto,nome_prodotto,categoria_prodotto,prezzo_prodotto) values (5,"DRAGONBALL Z","Film e Serie",10.00);
insert into prodotti(id_prodotto,nome_prodotto,categoria_prodotto,prezzo_prodotto) values (6,"BMW I8 MODELLINO","Collezioni",50.00);
insert into prodotti(id_prodotto,nome_prodotto,categoria_prodotto,prezzo_prodotto) values (7,"MONOPOLI, EDIZIONE PUGLIESE","Giochi da tavolo",35.00);
insert into prodotti(id_prodotto,nome_prodotto,categoria_prodotto,prezzo_prodotto) values (8,"ATTACCA LA BEFANA","Giochi D'imitazione",25.00);
insert into prodotti(id_prodotto,nome_prodotto,categoria_prodotto,prezzo_prodotto) values (9,"SPIDER-MAN: MILES MORALE","Videogiochi",50.00);
insert into prodotti(id_prodotto,nome_prodotto,categoria_prodotto,prezzo_prodotto) values (10,"PIPPO CALZELUNGHE","Film e Serie",20.00);


-- vendita dei prodotti
insert into vendite(id_vendita,data_vendita,Id_regione,Id_prodotto,prezzo_prodotto,quantità_prodotto,totale) values (1,"2024-01-02",1,10,20.00,120,2400);
insert into vendite(id_vendita,data_vendita,Id_regione,Id_prodotto,prezzo_prodotto,quantità_prodotto,totale) values (2,"2024-01-26",5,4,90.00,500,45000);
insert into vendite(id_vendita,data_vendita,Id_regione,Id_prodotto,prezzo_prodotto,quantità_prodotto,totale) values (3,"2023-08-05",3,3,30.00,1250,37500);
insert into vendite(id_vendita,data_vendita,Id_regione,Id_prodotto,prezzo_prodotto,quantità_prodotto,totale) values (4,"2023-06-25",1,7,35.00,550,19250);
insert into vendite(id_vendita,data_vendita,Id_regione,Id_prodotto,prezzo_prodotto,quantità_prodotto,totale) values (5,"2023-04-01",2,5,10.00,1000,10000);
insert into vendite(id_vendita,data_vendita,Id_regione,Id_prodotto,prezzo_prodotto,quantità_prodotto,totale) values (6,"2023-03-18",3,6,50.00,10,500);
insert into vendite(id_vendita,data_vendita,Id_regione,Id_prodotto,prezzo_prodotto,quantità_prodotto,totale) values (7,"2023-02-28",1,8,25.00,700,17500);
insert into vendite(id_vendita,data_vendita,Id_regione,Id_prodotto,prezzo_prodotto,quantità_prodotto,totale) values (8,"2023-02-04",2,10,20.00,1000,20000);
insert into vendite(id_vendita,data_vendita,Id_regione,Id_prodotto,prezzo_prodotto,quantità_prodotto,totale) values (9,"2023-01-29",3,9,50.00,50,2500);
insert into vendite(id_vendita,data_vendita,Id_regione,Id_prodotto,prezzo_prodotto,quantità_prodotto,totale) values (10,"2023-01-20",1,2,15.00,1200,18000);

-- Es. 1 verificare che i campi definiti come PK siano univoci
show columns from prodotti;
show columns from vendite;
show columns from regioni;

-- Es. 2 Esporre l'elenco dei soli prodotti venduti e per ognino di questi il fatturato totale per anno
SELECT 
nome_prodotto,
SUM(totale),
	YEAR(data_vendita) AS Anno_di_vendita
		FROM vendite
				JOIN prodotti ON vendite.id_prodotto = prodotti.id_prodotto
						GROUP BY Nome_Prodotto, Anno_di_vendita;

-- Es. 3 Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente
SELECT 
    YEAR(data_vendita) AS anno,
    id_regione,
    SUM(totale) AS Fatturato
		FROM vendite
			GROUP BY anno, id_regione
				ORDER BY anno asc, Fatturato DESC;

-- Es. 4 Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?
select categoria_prodotto, sum(prodotti.prezzo_prodotto) as "Totale Venduti"
	from prodotti
		join vendite on prodotti.Id_Prodotto = vendite.Id_Prodotto
			group by categoria_prodotto
				order by "Totale Venduti" desc;

-- Es. 5 Rispondere alla seguente domanda: quali sono, se ci sono i prodotto invenduti? Proponi due approcci risolutivi differenti
	-- 1
	SELECT * FROM prodotti
		WHERE prodotti.Id_Prodotto 
			NOT IN (SELECT DISTINCT prodotti.Id_Prodotto
				FROM vendite);

	-- 2
	SELECT * FROM prodotti
		LEFT JOIN vendite ON prodotti.Id_Prodotto = vendite.id_prodotto
			WHERE vendite.id_prodotto IS NULL;
				
-- es 6 Esporre l'elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente)
SELECT 
prodotti.Id_Prodotto,
prodotti.Nome_Prodotto,
MAX(vendite.data_vendita) 
	AS Data_Ordine
		FROM prodotti
			LEFT JOIN vendite
				ON prodotti.Id_Prodotto = vendite.id_prodotto
					GROUP BY prodotti.Id_Prodotto, prodotti.Nome_Prodotto 
						ORDER BY Data_Ordine desc;
